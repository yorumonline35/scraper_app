
const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const cors = require('cors');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.static('public'));
app.use(express.json());

app.post('/scrape', async (req, res) => {
  const { url } = req.body;

  if (!url) {
    return res.status(400).send('No URL provided');
  }

  try {
    const { data } = await axios.get(url);
    const $ = cheerio.load(data);

    const texts = [];
    $('h1, h2, h3, p, span').each((i, el) => {
      const text = $(el).text().trim();
      if (text) texts.push(text);
    });

    const images = [];
    $('img').each((i, el) => {
      const src = $(el).attr('src');
      if (src) images.push(src);
    });

    let htmlContent = `<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Scraped Data</title></head><body><table border='1' style='border-collapse: collapse; width: 100%;'>`;
    htmlContent += '<tr><th>Type</th><th>Content</th></tr>';

    texts.forEach(text => {
      htmlContent += `<tr><td>Text</td><td>${text.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</td></tr>`;
    });

    images.forEach(img => {
      htmlContent += `<tr><td>Image</td><td><img src='${img}' style='max-width:200px;'></td></tr>`;
    });

    htmlContent += '</table></body></html>';

    fs.writeFileSync('public/scraped_result.html', htmlContent);

    res.json({ success: true, downloadUrl: '/scraped_result.html' });
  } catch (error) {
    console.error(error);
    res.status(500).send('Error scraping the website.');
  }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
